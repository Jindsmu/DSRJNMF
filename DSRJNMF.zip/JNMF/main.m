%% load the real input data
XX1 = csvread('WSI_normalize.csv');
XX2 = csvread('gene_normalize.csv');
XX3 = csvread('miRNA_normalize.csv');

X1 =csvread('WSI_re_normalize.csv');
X2 = csvread('gene_re_normalize.csv');
X3 =csvread('miRNA_re_normalize.csv');

X1= X1./repmat(sqrt(sum(X1.^2,2)),1,size(X1,2));
X2= X2./repmat(sqrt(sum(X2.^2,2)),1,size(X2,2));
X3= X3./repmat(sqrt(sum(X3.^2,2)),1,size(X3,2));

[n,m1] = size(X1);
[n,m2] = size(X2);
[n,m3] = size(X3);
%% preprocess the real input data
degree = 2;
A1 = abs(corr(X1, X2));
A1=A1';
A2 = abs(corr(X1, X3));
A2=A2';
[D1,S1] = get_connectivity(X1,2);
[D2,S2] = get_connectivity(X2,2);
[D3,S3] = get_connectivity(X3,2);
K = 7;
%% SVD iniialization
X = [X1 X2 X3];
[U,S,V]=svd(X);
s_sum = sum(S); 
W(:,1) = sqrt(S(1,1))*U(:,1);
H(1,:) = sqrt(S(1,1))*V(:,1)';
for j = 2 : K
    x = U(:,j);
    y = V(:,j);
    xp = (x>=0).*x;
    xn = (x<0).*(-x);
    yp = (y>=0).*y;
    yn = (y<0).*(-y);
    xpnrm = norm(xp);
    ypnrm = norm(yp);
    mp = xpnrm * ypnrm;
    xnnrm = norm(xn);
    ynnrm = norm(yn);
    mn = xnnrm * ynnrm;
    if mp > mn
        u = xp/xpnrm;
        v = yp/ypnrm;
        sigma = mp;
    else
        u = xn/xnnrm;
        v = yn/ynnrm;
        sigma = mn;
    end
    W(:,j) = sqrt(S(j,j)*sigma)*u;
    H(j,:) = sqrt(S(j,j)*sigma)*v';
end
W = abs(W);
save W_original.mat W;
H = abs(H);
H1 = H(:,1:m1);
H2 = H(:,m1+1:m1+m2);
H3 = H(:,m1+m2+1:m1+m2+m3);
save H1_original.mat H1;
save H2_original.mat H2;
save H3_original.mat H3;
%% applying MDJNMF
L11 = 0.001; L12 = 0.001;
L2 = 0.001; r1 = 0.001; r2 = 0.001; a1 = 0.1; maxiter = 500;
tic
[W,H1,H2,H3,errorx_list,errorx] = JNMF_comodule(X1,X2,X3,A1,A2,D1,D2,D3,S1,S2,S3,a1,r1,r2,L11,L12,L2,K,maxiter);
toc
