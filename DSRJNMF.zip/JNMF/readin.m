function [sheetdata] = readin(filename)
sheetdata = xlsread(filename,'cellrange','sheet');
end